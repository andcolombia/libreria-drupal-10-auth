<?php

namespace Drupal\openid_connect\Form;

/**
 * Provides the edit form for the OpenID Connect client entity.
 */
class OpenIDConnectClientEditForm extends OpenIDConnectClientFormBase {
}
